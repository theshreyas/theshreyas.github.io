<?php

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "magehub";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


$filename = 'csv/magento.csv';
$i=0;
$errors = array();
if (($h = fopen("{$filename}", "r")) !== FALSE) 
{
	while (($data = fgetcsv($h, 1000, ",")) !== FALSE) 
	{
		if($i != 0){
			// print_r($data);
			$title = $data[2];
			$price = $data[4];
			$price = str_replace(array('$',','), '', $price);
			// if(strpos($price, 'Regular Price') !== false){
			// 	$prices = explode('Regular Price', $price);
			// 	$price = explode('Special Price', $prices[0]);
			// 	$price = $price[1];
			// }
			// echo $price;
			// echo "<br>";
			$avg_review = $data[3];
			$avg_review = str_replace(array('-'), '', $avg_review);
			$description = $data[6];
			// print_r($price);die;
			$url = $data[8];
			$image = 'https:'.$data[5];
			$company = $data[1];
			$tags = '';//$data[0];
			$category = $data[0];
			$github_link = '';//$data[0];
			$require_license = 0;//$data[0];

			$sql = "INSERT INTO ext_04May0140(title,description,price,url,avg_review,image,company,tags,category,github_link,require_license) VALUES ('$title','$description','$price','$url','$avg_review','$image','$company','$tags','$category','$github_link','$require_license')";
			echo $sql;die;
			if(!mysqli_query($conn, $sql)){
				$errors[] = mysqli_error($conn);
				// echo json_encode(array('status'=>false,'error'=>mysqli_error($conn)));
			}
		}
		$i++;
	}

	fclose($h);
}