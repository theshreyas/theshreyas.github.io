<?php

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "magehub";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


$filename = '/home/hp/Downloads/landofcoder.csv';

$i=0;
$errors = array();
if (($h = fopen("{$filename}", "r")) !== FALSE) 
{
	while (($data = fgetcsv($h, 1000, ",")) !== FALSE) 
	{
		if($i != 0){
			$title = $data[3];
			$description = $data[5];
			$description = str_replace('Learn More', '', $description);
			$price = $data[4];
			$price = str_replace(array('$',','), '', $price);
			// print_r($price);die;
			$url = $data[7];
			$avg_review = 'null';//$data[4];
			$image = $data[8];
			$company = 'Landofcoder';
			$tags = '';//$data[0];
			$category = '';//$data[5];
			$github_link = '';//$data[0];
			$require_license = 0;//$data[0];

			$sql = "INSERT INTO ext(title,description,price,url,avg_review,image,company,tags,category,github_link,require_license) VALUES ('$title','$description','$price','$url','$avg_review','$image','$company','$tags','$category','$github_link','$require_license')";

			if(!mysqli_query($conn, $sql)){
				$errors[] = mysqli_error($conn);
				// echo json_encode(array('status'=>false,'error'=>mysqli_error($conn)));
			}
		}
		$i++;
	}

	fclose($h);
}