<?php

$servername = "localhost";
$username   = "root";
$password   = "root";
$dbname     = "magehub";
$conn       = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// $filename = '/var/www/html/MageHub/LPT/githubfinal.csv';
$filename = '/home/user/Downloads/githublist_(4).csv';
// $filename = '/home/user/Downloads/githublist8Jun22.csv';
// $filename = '/home/user/Downloads/githublist8Jun22_2.csv';
// $filename = '/home/user/Downloads/githublist8jun22_3.csv';
// $filename = '/home/user/Downloads/githublist11jun.csv';
// $filename = '/home/user/Downloads/githublist_.csv';
// $filename = '/home/user/Downloads/githublist15jun.csv';

$i      = $c1      = $c2      = 0;
$errors = array();
if (($h = fopen("{$filename}", "r")) !== false) {
    while (($data = fgetcsv($h, 1000, ",")) !== false) {
        if ($i != 0) {
            $webscraperorder    = trim($data[0]);
            $webscraperstarturl = trim($data[1]);
            $title              = trim($data[2]);
            $link               = trim($data[3]);
            $url                = trim($data[4]);
            $about              = trim($data[5]);
            $g_lastupdated      = trim($data[6]);
            $g_commits          = trim($data[7]);
            $tags               = trim($data[8]);
            $g_watching         = trim($data[9]);
            $g_forks            = trim($data[10]);
            $g_contributors     = trim($data[11]);
            $usedby             = trim($data[12]);
            $languages          = trim($data[13]);
            $g_stars            = str_replace(',', '', trim($data[14]));
            $g_readonly         = trim($data[15]);
            $image              = trim($data[16]);

            // print_r($data);die;
            $title       = ltrim($title, '/');
            $title       = explode('/', trim($title));
            $company     = $title[0];
            $title       = $title[1];
            $description = addcslashes($about, "'");
            // $price       = 0;
            // $price = str_replace(array('$',','), '', $price);
            // print_r($price);die;
            $avg_review = ''; //$data[4];
            // $company         = 'Amasty';
            $github_link     = $url; //$data[0];
            $require_license = 0; //$data[0];
            $category        = ''; //$data[5];
            $g_readonly      = $g_readonly == "read-only" ? 1 : 0;
            $query           = "SELECT id FROM github WHERE url=?";
            $stmt            = $conn->prepare($query);
            $stmt->bind_param("s", $url);
            $stmt->execute();
            $result           = $stmt->get_result();
            $IdAlreadyPresent = $result->fetch_row()[0] ?? false;
            if (strpos($tags, '{') !== false) {
                $tags = json_decode($tags, true);
                $tags = array_column($tags, 'tags');
                $tags = implode(',', $tags);
            } else {
                $tags = preg_replace('/\s*\R\s*/', ' ', trim($tags));
                $tags = str_replace(' ', ',', $tags);
            }
            while (strlen($tags) > 255) {
                $tags = substr($x, 0, strripos($x, ','));
            }
            if ($IdAlreadyPresent) {
                $sql  = "UPDATE github SET g_lastupdated=?,g_commits=?, g_stars=?, description=?, image=?, g_watching=?, g_forks=?, g_contributors=?,g_readonly=?, tags=? WHERE id=?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param('sss sss ssd sd', $g_lastupdated, $g_commits, $g_stars, $description, $image, $g_watching, $g_forks, $g_contributors, $g_readonly, $tags, $IdAlreadyPresent);
                $stmt->execute();
                $c1++;
            } else {

                $sql = "INSERT INTO github(title,description,url,image,company,tags,category,github_link,require_license,g_lastupdated,g_commits,g_watching,g_forks,g_contributors,g_stars,g_readonly) VALUES ('$title','$description','$url','$image','$company','$tags','$category','$github_link','$require_license','$g_lastupdated','$g_commits','$g_watching','$g_forks','$g_contributors','$g_stars','$g_readonly')";

                if (!mysqli_query($conn, $sql)) {
                    // $errors[] = $sql;
                    $errors[] = [mysqli_error($conn), $sql];
                    // print_r($errors);die;
                    // echo json_encode(array('status'=>false,'error'=>mysqli_error($conn)));
                }
                $c2++;

            }
        }
        $i++;
    }

    fclose($h);
}
if (!empty($errors)) {
    echo "<pre>";
    print_r($errors);
} else {
    echo "success";
}
echo "\n<br>";
echo $c1 . " updated entries";
echo "\n<br>";
echo $c2 . " new entries";
echo "\n<br>";
