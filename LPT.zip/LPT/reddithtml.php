<?php
  ini_set('display_errors', 1); 
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>EXT Dashboard</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/datatables.min.css"/>
  <link rel="stylesheet" type="text/css" href="css/select2.min.css"/>
  <script src="js/jquery.min.js"></script>
  <script src="js/select2.min.js"></script>
  <script type="text/javascript" src="js/datatables.min.js"></script>
  <script type="text/javascript" src="js/jquery.dataTables.yadcf.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/moment.min.js"></script>
  <script src="js/datetime.moment.js"></script>
  <style type="text/css">
    p {display: inline;}
    .taglabel{
        padding: 0px 10px 0px 10px;
        border: 1px solid #ccc;
        -moz-border-radius: 1em;
        -webkit-border-radius: 1em;
        border-radius: 1em;
    }
    #example{
        table-layout: fixed;
        word-wrap:break-word;
    }
    /* Absolute Center Spinner */
    .loading {
      position: fixed;
      z-index: 999;
      height: 2em;
      width: 2em;
      overflow: show;
      margin: auto;
      top: 0;
      left: 0;
      bottom: 0;
      right: 0;
    }

    /* Transparent Overlay */
    .loading:before {
      content: '';
      display: block;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0,0,0,0.3);
    }
    .loading:not(:required):after {
      content: '';
      display: block;
      font-size: 10px;
      width: 1em;
      height: 1em;
      margin-top: -0.5em;
    }
input[type="checkbox"] {
  transform:scale(2, 2);
}
  </style>
</head>
<body>
<div id="element"></div>
<?php
  $servername = "localhost";
  $username = "root";
  $password = "root";
  $dbname = "magehub";
  $conn = new mysqli($servername, $username, $password, $dbname);
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  } 
  $data=mysqli_fetch_assoc(mysqli_query($conn,"SELECT count(*) as count,MAX(id) as max from ext"));
  $totalcount = $data['count'];
  $data=mysqli_fetch_assoc(mysqli_query($conn,"SELECT count(*) as count from ext where tags != ''"));
  $reviewed = $data['count'];
  ?>
  <!-- <div class="jumbotron text-center"> -->
    <!-- <h1>LPT Dashboard</h1> -->
    <!-- <p>Resize this responsive page to see the effect!</p>  -->
  <!-- </div> -->
  Total Count : <?=$totalcount?>
  Reviews Done : <?=$reviewed?>
  <br>
<!--   <button class="delete_all">Delete</button>
  <button id="save">Save</button> -->
  <div class="container">
    <div class="row">
      <table id="example" class="display" style="width:100%">
        <thead>
          <tr>
              <th>Title</th>
              <th>$</th>
              <th>Description</th>
              <th>Category</th>
              <th>Tags</th>
              <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php
            // $randomfetch = $conn->query("SELECT * FROM lpt AS r1 JOIN
            //               (SELECT CEIL(RAND() * (SELECT MAX(id) FROM lpt)) AS id)
            //               AS r2 WHERE r1.id >= r2.id
            //               ORDER BY r1.id ASC LIMIT 40");
            $limit = isset($_GET['l']) ? $_GET['l']: 100;
            $fetch = $conn->query("SELECT * FROM ext where tags = '' limit 800");
            if($fetch->num_rows > 0)
            {
              while($row = $fetch->fetch_assoc())
              {
                $tags = explode(",", $row['tags']);
          ?>  
                <tr data-id="<?php echo $row['id'];?>" data-url="<?php echo $row['url'];?>">
                    <!-- <td><input type="checkbox" class="s_check"></td> -->
                    <td class="title openurl"><?php echo $row['title']?></td>
                    <td><?php echo $row['price'];?></td>
                    <td><?php echo $row['description'];?></td>
                    <td><?php echo $row['category'];?></td>
                    <td class="tags edit" data-toggle="modal" data-target="#myModal"><?php 
                    if($tags[0]!="")
                      foreach($tags as $tag){
                        echo "<span class='taglabel'>".$tag."</span>";
                      }
                    ?>
                        <input type="hidden" class="hiddentags" value="<?php echo $row['tags']?>">
                      
                    </td>
                    <td>
                        <span class="delete">Delete</span>
                    </td>
                </tr>
<?php
              }
            }
            else{
                echo "no data found<br>";
            }
?>
        </tbody>
    </table>

    <!-- Modal -->
    <div id="myModal" class="modal fade" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Edit Tags</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
          <a href="/r/categories.php" target="_blank">Add New Tag</a>
            <div class="form-group">
                <select name="state" id="select2" multiple="multiple">
                </select>
                <input type="hidden" value="" id="hidden">
            </div>
            <div class="tag_display">

            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="savetags btn btn-default btn-success" data-dismiss="modal">Save</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>

      </div>
    </div>


  <!-- </div> -->
</div>
<script type="text/javascript">
$(document).ready(function() {

    // var map = {}; // You could also use an array
    // onkeydown = onkeyup = function(e){
    //   e = e || event; // to deal with IE
    //   map[e.keyCode] = e.type == 'keydown';
    //   if(map[16] && map[40]) //shift & down pressed at same time
    //   {
    //     $(".s_check:checked:last").closest('tr').next().find('.s_check').prop('checked', true);
    //   }
    //   if(map[46] && map[46] === true) //delete pressed
    //   {
    //     delete_all();
    //     map = {};
    //   }
    //   if(map[16] && map[38]) //shift & down pressed at same time
    //  {
    //     $(".s_check:checked:last").prop('checked', false);
    //  }
    // }
    // select next span width 
    $("#select2").select2({ width: 'resolve' });
    $('#select2').next().css( "width", "200px");
    $.fn.dataTable.moment('d-m-Y');
    var myTable = $('#example').DataTable({
        "bStateSave": true,
        "fnStateSave": function (oSettings, oData) {
            localStorage.setItem('offersDataTables', JSON.stringify(oData));
        },
        "fnStateLoad": function (oSettings) {
            return JSON.parse(localStorage.getItem('offersDataTables'));
        },
        "autoWidth": false,
        "pageLength": 9,
        "columnDefs": [
        //   { "targets": 0,"width": "10px","orderable": false,"sortable": false},
          { "targets": 1,"width": "11px" },//price
          { "targets": 2,"sortable": false,"width": "400px" },
        //   { "targets": 4,"width": "24px" },//score
          { "targets": 5,"sortable": false,"width": "35px" } //Action
        //   // { "targets": 7,"width": "24px" },
        //   // { "targets": 8,"width": "10px" },//favorite
        ],
        responsive: true,
        // "order": [[ 2, "desc" ]],
        "processing": true,
        "initComplete": function(settings, json) {
            $('.loading').hide();
        }
    });

    // yadcf.init(myTable, [
    // {
    //     column_number : 3,
    //     filter_type: "multi_select",
    //     select_type: 'select2'
    // }, 
    // {
    //     column_number: 5,
    //     select_type: 'select2',
    //     select_type_options: {
    //         width: '150px',
    //         placeholder: 'Select tag',
    //         allowClear: true  // show 'x' (remove) next to selection inside the select itself
    //     },
    //     column_data_type: "html",
    //     html_data_type: "text",
    //     filter_reset_button_text: false // hide yadcf reset button
    // }
    // ]);
    $(document).on("click", ".openurl", function() {
        $url = $(this).closest('tr').data('url');
        window.open($url);
        return false;
    });
    // $(document).on("click", ".edit", function() {
    //     $id = $(this).closest('tr').data('id');
    //     $('#hidden').val($id);
    //     var tags = $(this).closest('tr').find(".hiddentags").val().split(',');
    //     $("#select2").val(tags).trigger("change");
    // });
    $("#myModal").on('shown.bs.modal', function(){
        var id = $("#hidden").val();
        var tag_display= [];
        $.ajax({
            'url':'tags.php',
            'type':'POST',
            'dataType': 'json',
            'data':{id: id,type:'fetch'},
            'success':function(response){
              $('#select2').empty().trigger("change").append(
                  $.map(response.result, function(v, i){ 
                    return $('<option>', { val: v.name, text: v.name }); 
                  })
                );
              if(response.selected != ''){
                $("#select2").val(response.selected.split(',')).trigger("change");
              }
            }
        });
    });

    // $(document).on('click','[class^="star-"]',function(){
    //     var $this = $(this);
    //     var id = $this.closest('tr').data('id');
    //     $.ajax({
    //         'url':'tags.php',
    //         'type':'POST',
    //         'dataType': 'json',
    //         'data':{id: id,type:'favorite'},
    //         'success':function(response){
    //             if(response.status == true){
    //               $this.toggleClass("star-on star-off");
    //             }
    //         }
    //     });
    // });
    $(document).on('click','.savetags',function(){
        var id = $("#hidden").val();
        var tags = $("#select2").val();
        $.ajax({
            'url':'tags.php',
            'type':'POST',
            'dataType': 'json',
            'data':{id: id,tags:tags,type:'update'},
            'success':function(response){
                if(response.status == true){
                  $('[data-id="'+id+'"]').find(".tags").html(response.html);
                  $('[data-id="'+id+'"]').find(".hiddentags").val(tags.join());
                  // myTable.draw();
                }
            }
        });
    });
    // function delete_all(){
    //     var allVals = [];
    //     $(".s_check:checked").each(function() {  
    //         allVals.push($(this).closest('tr').data('id'));
    //     }); 
    //     if(allVals.length <=0)  
    //         alert("Please select row.");  
    //     else
    //     {
    //         WRN_PROFILE_DELETE = "Are you sure you want to delete "+allVals.length+" row/s?";  
    //         var check = confirm(WRN_PROFILE_DELETE);  
    //         if(check == true)
    //         {
    //             $.ajax({
    //                 'url':'delete.php',
    //                 'type':'POST',
    //                 'data':{id: allVals,type:'mass'},
    //                 'success':function(response){
    //                     $.each(allVals,function(index,val) {  
    //                         $('[data-id="'+val+'"]').remove();
    //                     });
    //                 $("#check_all").prop('checked',false);  

    //                     // if(response == 'success')
    //                     // $this.closest('tr').hide();
    //                 }
    //             });
    //         }
    //     }  
    // }
    // $(document).on('click','.delete_all',delete_all);
    // $(document).on('click','#check_all',function(){
    //     if($(this).is(':checked',true))  
    //         $(".s_check").prop('checked', true);  
    //     else  
    //         $(".s_check").prop('checked',false);  
    // });

    $(document).on('click','.delete',function(){
        $this = $(this);
        $id = $this.closest('tr').data('id');

        WRN_PROFILE_DELETE = "Are you sure you want to delete id #"+$id+" ?";  
        var check = confirm(WRN_PROFILE_DELETE);  
        if(check == true)
        {
          $.ajax({
              'url':'delete.php',
              'type':'POST',
              'data':{id: $id},
              'success':function(response){
                  if(response == 'success')
                      $this.closest('tr').hide();
                    else
                      alert(response);
              }
          });
        }

    });
});
</script>
</body>
</html>