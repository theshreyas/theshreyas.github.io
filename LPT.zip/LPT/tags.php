<?php 
try{
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "magehub";
	$conn = new mysqli($servername, $username, $password, $dbname);
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}
	if($_POST['type'] && $_POST['type']=='new'){
		if($_POST['tag']){
			$tag = $_POST['tag'];
			$sql = "INSERT INTO tags(name) VALUES ('$tag')";
			// $sql = "DELETE FROM ext WHERE id IN ($id_string)";
			if(mysqli_query($conn, $sql)){
				echo json_encode(array('status'=>true,'html'=>'added new tag'.$_POST['tag']));
			}
			else{
				echo json_encode(array('status'=>false,'error'=>mysqli_error($conn)));
			}
		}
	}
	else if($_POST['type'] && $_POST['type']=='update'){
		$id =$_POST['id'];
		$tags_arr =$_POST['tags'];
		$tags = implode(",",$tags_arr);
		$sql = "UPDATE ext SET tags = '$tags' WHERE id = '$id'";
		// $sql = "DELETE FROM ext WHERE id IN ($id_string)";
		if(mysqli_query($conn, $sql)){
			$response = "";
			foreach ($tags_arr as $tag) {
				$response .= "<span class='taglabel'>".$tag."</span>";
			}
			echo json_encode(array('status'=>true,'html'=>$response));
		} 
		else{
		    echo json_encode(array('status'=>false,'error'=>mysqli_error($conn)));
		}
		mysqli_close($conn);
		}
	else if($_POST['type'] && $_POST['type']=='categoryupdate'){
		$id =$_POST['id'];
		$category =$_POST['category'];
		$sql = "UPDATE ext SET category = '$category' WHERE id = '$id'";
		// $sql = "DELETE FROM ext WHERE id IN ($id_string)";
		if(mysqli_query($conn, $sql)){
			echo json_encode(array('status'=>true,'category'=>$category));
		} 
		else{
		    echo json_encode(array('status'=>false,'error'=>mysqli_error($conn)));
		}
		mysqli_close($conn);
		}
	else if($_POST['type'] && $_POST['type']=='descrupdate'){
		$id =$_POST['id'];
		$descr =$_POST['descr'];
		$sql = "UPDATE ext SET description = '$descr' WHERE id = '$id'";
		// $sql = "DELETE FROM ext WHERE id IN ($id_string)";
		if(mysqli_query($conn, $sql)){
			echo json_encode(array('status'=>true,'descr'=>$descr));
		} 
		else{
		    echo json_encode(array('status'=>false,'error'=>mysqli_error($conn)));
		}
		mysqli_close($conn);
		}
	else if($_POST['type'] && $_POST['type']=='fetch'){
		$id =$_POST['id'];
        $fetch = $conn->query("SELECT name FROM tags");
        $all_tags = [];
        if($fetch->num_rows > 0)
        {
			while($row = $fetch->fetch_assoc())
			{
				$all_tags[] = $row;
				// print_r($row['tags']);
			}
        	$selected = $conn->query("SELECT tags FROM ext WHERE id = '$id'");
	        if($selected->num_rows > 0)
	        {
	        	$row=mysqli_fetch_array($selected,MYSQLI_ASSOC);
	        	$selected_tags = $row['tags'];
	        }
			echo json_encode(array('status'=>true,'result'=>$all_tags,'selected'=>$selected_tags));
      	}
      	else{
		    echo json_encode(array('status'=>false,'error'=>'no record/s found with '.$id));
      	}

	}
	// else if($_POST['type'] && $_POST['type']=='favorite'){
	// 	$id =$_POST['id'];
	// 	$sql = "UPDATE ext SET favorite = !favorite WHERE id = '$id'";
	// 	if(mysqli_query($conn, $sql)){
	// 		echo json_encode(array('status'=>true));
	// 	} 
	// 	else{
	// 	    echo json_encode(array('status'=>false,'error'=>mysqli_error($conn)));
	// 	}
	// 	mysqli_close($conn);
	// }
}
catch(Throwable $e) {
	echo 'Message: ' .$e->getMessage();
	file_put_contents('log/deletelog_'.date("j.n.Y").'.txt', 'Message: ' .$e->getMessage().PHP_EOL, FILE_APPEND);

}
?>