<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$homeurl = "http://localhost/MageHub/LPT/ext.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>EXT Dashboard</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/datatables.min.css"/>
  <link rel="stylesheet" type="text/css" href="css/select2.min.css"/>
  <script src="js/jquery.min.js"></script>
  <script src="js/select2.min.js"></script>
  <script type="text/javascript" src="js/datatables.min.js"></script>
  <script type="text/javascript" src="js/jquery.dataTables.yadcf.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/moment.min.js"></script>
  <script src="js/datetime.moment.js"></script>
  <style type="text/css">
    .container {
        max-width: 1500px !important;
    }
    p {display: inline;}
    .taglabel{
        padding: 0px 10px 0px 10px;
        border: 1px solid #ccc;
        -moz-border-radius: 1em;
        -webkit-border-radius: 1em;
        border-radius: 1em;
    }
    #example{
        table-layout: fixed;
        word-wrap:break-word;
    }
    /* Absolute Center Spinner */
    .loading {
      position: fixed;
      z-index: 999;
      height: 2em;
      width: 2em;
      overflow: show;
      margin: auto;
      top: 0;
      left: 0;
      bottom: 0;
      right: 0;
    }
    /* Transparent Overlay */
    .loading:before {
      content: '';
      display: block;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0,0,0,0.3);
    }
    .loading:not(:required):after {
      content: '';
      display: block;
      font-size: 10px;
      width: 1em;
      height: 1em;
      margin-top: -0.5em;
    }
    input[type="checkbox"] {
      transform:scale(2, 2);
    }
    #header_top button.active{ background: red; }
    span.edit,span.delete { cursor: pointer; }
  </style>
</head>
<body>
<?php
$servername = "localhost";
$username   = "root";
$password   = "root";
$dbname     = "magehub";
$conn       = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$categories_arr = array('translations', 'mobile', 'personalization', 'productcontent', 'richmedia', 'sitesearch', 'blog', 'social', 'marketplaceaddon', 'marketplacesolutions', 'addressverification', 'crossborderfulfil', 'ordermgmt', 'warehousemgmt', 'shippingcustom', 'helpdesk', 'livechat', 'erp', 'taxes', 'checkout', 'fraud', 'payment', 'testing', 'hosting', 'sitemonitoring', 'performance', 'sitemap', 'reporting', 'admintools', 'emailmarketing', 'crm', 'seo', 'marketingautomation', 'advertising', 'comarisonshoppingengines', 'gifts', 'marketplacefeeds', 'pos', 'pricingpromotions', 'loyaltyrewards');

$data       = mysqli_fetch_assoc(mysqli_query($conn, "SELECT count(*) as count from ext"));
$totalcount = $data['count'];

$data                = mysqli_fetch_assoc(mysqli_query($conn, "SELECT count(*) as count from ext where category IN ( '" . implode("', '", $categories_arr) . "' )"));
$categoriesCompleted = $data['count'];

$limit = isset($_GET['l']) ? $_GET['l'] : 100;

$show_duplicates = isset($_GET['dpl']) && $_GET['dpl'] == true ? true : false;
$duplicat_url    = !$show_duplicates ? '?dpl=true' : $homeurl;
$show_all        = isset($_GET['all']) && $_GET['all'] == true ? true : false;
$show_all_url    = !$show_all ? '?all=true' : $homeurl;
$github_ext_url  = isset($_GET['github_ext']) && $_GET['github_ext'] == true ? true : false;
$github_ext      = !$github_ext_url ? '?github_ext=true' : $homeurl;
// if ($show_duplicates) {

//     $Duplicates    = "SELECT count(*) as count,url from ext group by url having count > 1";
//     $fetch         = $conn->query($Duplicates);
//     $data          = $fetch->fetch_all(MYSQLI_ASSOC);
//     $DuplicateUrls = array_column($data, 'url');
//     $query         = "SELECT * FROM ext where url IN ( '" . implode("', '", $DuplicateUrls) . "' ) order by url asc;";
// } else if ($show_all) {

//     $query = "SELECT * FROM ext where price = 0;";
// } else if ($github_ext_url) {
    $query = "SELECT * FROM github;";
// } else {

//     $query = "SELECT * FROM ext where category NOT IN ( '" . implode("', '", $categories_arr) . "' );";
// }

$fetch = $conn->query($query);

?>
  <div class="container">

    <div id="header_top" style="height: 30px;margin: 10px;">
    <!-- <span style="float: left;"> -->
    <!-- Total Count : 120  Reviews Done : 0  </span> -->
  <!--   <button class="delete_all">Delete</button>
    <button id="save">Save</button> -->
      <span style="float:left;"><?=$totalcount?> -</span>
      <span style="float:left;"><?=$categoriesCompleted?> </span>
      <span style="float:left;" id="filteredEntries">=</span>
      <button id="db_backup" style="float: right;margin-left: 5px;">Take Table Backup</button>
      <a href="<?=$duplicat_url?>"><button <?php if ($show_duplicates) {
    echo 'class="active"';
}
?> style="float: right;margin-left: 5px;">Duplicates</button></a>
      <a href="<?=$show_all_url;?>"><button <?php if ($show_all) {
    echo 'class="active"';
}
?> style="float: right;">Show All</button></a>
      <!-- <a href="<?=$no_cat_url?>"><button <?php //if($no_cat) echo 'class="active"';?> style="float: right;">No Categories</button></a> -->
    </div>

    <div class="row">
      <table id="example" class="display" style="width:100%">
        <thead>
          <tr>
              <th>Title</th>
              <?php if ($github_ext_url) { ?>
              <th>Last Updated</th>
              <th>Stars</th>
              <?php } else{ ?>
              <th>Company</th>
              <?php } ?>
              <th>Description</th>
              <th>Category</th>
              <th>Tags</th>
              <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php
// $randomfetch = $conn->query("SELECT * FROM lpt AS r1 JOIN
//               (SELECT CEIL(RAND() * (SELECT MAX(id) FROM lpt)) AS id)
//               AS r2 WHERE r1.id >= r2.id
//               ORDER BY r1.id ASC LIMIT 40");

// $fetch = $conn->query("SELECT * FROM ext where tags = '' limit 800");
if ($fetch->num_rows > 0) {
    while ($row = $fetch->fetch_assoc()) {
        $tags = explode(",", $row['tags']);
        ?>
                <tr data-id="<?php echo $row['id']; ?>" data-url="<?php echo $row['url']; ?>">
                    <!-- <td><input type="checkbox" class="s_check"></td> -->
                    <td class="title openurl" title="<?php echo $row['url']; ?>"><?php echo $row['title'] ?></td>
                    <?php if ($github_ext_url) { ?>
                        <td><?php echo $row['g_lastupdated']; ?></td>
                        <td><?php echo $row['g_stars']; ?></td>
                    <?php } else{ ?>
                        <td><?php echo $row['company']; ?></td>
                    <?php } ?>

                    <td data-toggle="modal" data-target="#viewdescription" class="descriptionname"><?php echo htmlspecialchars($row['description']); ?></td>
                    <td data-toggle="modal" data-target="#viewcategory" class="categoryname">
                      <?php echo $row['category']; ?></td>
                    <td class="tags edit" data-toggle="modal" data-target="#tagsEdit"><?php
if ($tags[0] != "") {
            foreach ($tags as $tag) {
                echo "<span class='taglabel'>" . $tag . "</span>";
            }
        }?>
                        <input type="hidden" class="hiddentags" value="<?php echo $row['tags'] ?>">
                    </td>
                    <td>
                        <span class="edit" data-toggle="modal" data-target="#EditRow">Edit</span>
                        <span class="delete" <?php if ($show_duplicates) { echo 'class="githubdelete"';}?> >Delete</span>
                    </td>
                </tr>
<?php
}
}
// else{
//     echo "no data found<br>";
// }
?>
        </tbody>
    </table>

    <!-- Modal -->
    <div id="viewdescription" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Edit Description</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            <div class="form-group">
                <textarea style="width: 470px;height: 150px;" id="modaldescription"></textarea>
                <input type="hidden" value="" id="descriptionhidden">
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="savedescription btn btn-default btn-success" data-dismiss="modal">Save</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>

      </div>
    </div>

    <!-- Modal -->
    <div id="EditRow" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Edit Row</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            <div class="form-group">
                <textarea style="width: 470px;height: 150px;" id="row_description"></textarea>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="savedescription btn btn-default btn-success" data-dismiss="modal">Save</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>

      </div>
    </div>
    <!-- Modal -->
    <div id="viewcategory" class="modal fade" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Edit Category</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            <div class="form-group">

                <select id="category_filter" name="category_filter">
                  <optgroup label="Content & Customizations">
                    <option value="translations">Translations & Localization</option>
                    <option value="mobile">Mobile</option>
                    <option value="personalization">Personalization & Experience Management</option>
                    <option value="productcontent">Product Content</option>
                    <option value="richmedia">Rich Media</option>
                    <option value="sitesearch">Site Search & Navigation</option>
                    <option value="blog">Blog</option>
                  </optgroup>
                  <optgroup label="Social">
                    <option value="social">Social</option>
                  </optgroup>
                  <optgroup label="MultiVendor/Marketplace">
                    <option value="marketplaceaddon">Marketplace Add-Ons</option>
                    <option value="marketplacesolutions">Marketplace Solutions</option>
                  </optgroup>
                  <optgroup label="Shipping & Fulfillment">
                    <option value="addressverification">Address Verification</option>
                    <option value="crossborderfulfil">Cross Border Fulfillment</option>
                    <option value="ordermgmt">Order Management (OMS)</option>
                    <option value="warehousemgmt">Warehouse Management System (WMS)</option>
                    <option value="shippingcustom">Shipping Customizations</option>
                  </optgroup>
                  <optgroup label="Customer Support">
                    <option value="helpdesk">Helpdesk</option>
                    <option value="livechat">Livechat</option>
                  </optgroup>
                  <optgroup label="Accounting & Finance">
                    <option value="erp">ERP & Accounting</option>
                    <option value="taxes">Taxes</option>
                  </optgroup>
                  <optgroup label="Payments & Security">
                    <option value="checkout">Checkout Enhancements</option>
                    <option value="fraud">Fraud Prevention</option>
                    <option value="payment">Payment Integration</option>
                  </optgroup>
                  <optgroup label="Site Optimization">
                    <option value="testing">Testing & Segmentation</option>
                    <option value="hosting">Hosting</option>
                    <option value="sitemonitoring">Site Monitoring</option>
                    <option value="performance">Performance</option>
                    <option value="sitemap">Sitemap</option>
                  </optgroup>
                  <optgroup label="Administration">
                    <option value="reporting">Reporting & Analytics</option>
                    <option value="admintools">Admin Tools</option>
                  </optgroup>
                  <optgroup label="Marketing">
                    <option value="emailmarketing">Email Marketing</option>
                    <option value="crm">CRM</option>
                    <option value="seo">SEO/SEM</option>
                    <option value="marketingautomation">Marketing Automation</option>
                    <option value="advertising">Advertising</option>
                  </optgroup>
                  <optgroup label="Sales & Motivation">
                    <option value="comarisonshoppingengines">Comparison Shopping Engines</option>
                    <option value="gifts">Gifts</option>
                    <option value="marketplacefeeds">Marketplace Feeds</option>
                    <option value="pos">Point of Service (POS)</option>
                    <option value="pricingpromotions">Pricing & Promotions</option>
                    <option value="loyaltyrewards">Rewards & Loyalty</option>
                  </optgroup>
                </select>
                <input type="hidden" value="" id="categoryhidden">
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="savecategory btn btn-default btn-success" data-dismiss="modal">Save</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>

      </div>
    </div>
    <!-- Modal -->
    <div id="tagsEdit" class="modal fade" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Edit Tags</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
          <a href="/r/categories.php" target="_blank">Add New Tag</a>
            <div class="form-group">
                <select name="state" id="select2" multiple="multiple">
                </select>
                <input type="hidden" value="" id="hidden">
            </div>
            <div class="tag_display">

            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="savetags btn btn-default btn-success" data-dismiss="modal">Save</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>

      </div>
    </div>
<div><button id="downloadcsv" style="float: right;margin-left: 5px;">Download CSV</button></div>

  <form method="POST" action="upload.php" enctype="multipart/form-data">
    <div class="upload-wrapper">
      <span class="file-name">Choose a file...</span>
      <label for="file-upload">Browse<input type="file" id="file-upload" name="uploadedFile"></label>
    </div>

    <input type="submit" name="uploadBtn" value="Upload" />
  </form>
</div>
<script type="text/javascript">
$(document).ready(function() {

    // var map = {}; // You could also use an array
    // onkeydown = onkeyup = function(e){
    //   e = e || event; // to deal with IE
    //   map[e.keyCode] = e.type == 'keydown';
    //   if(map[16] && map[40]) //shift & down pressed at same time
    //   {
    //     $(".s_check:checked:last").closest('tr').next().find('.s_check').prop('checked', true);
    //   }
    //   if(map[46] && map[46] === true) //delete pressed
    //   {
    //     delete_all();
    //     map = {};
    //   }
    //   if(map[16] && map[38]) //shift & down pressed at same time
    //  {
    //     $(".s_check:checked:last").prop('checked', false);
    //  }
    // }
    // select next span width
    $("#select2").select2({ width: 'resolve' });
    $('#select2').next().css( "width", "200px");
    // $("#category_filter").select2({ width: 'resolve' });
    // $('#category_filter').next().css( "width", "400px");
    $.fn.dataTable.moment('d-m-Y');
    const queryString = window.location.search;
    // if (queryString.includes("?github_ext=")) {
    if (true) {
      var myTable = $('#example').DataTable({
          // "bStateSave": true,
          "fnStateSave": function (oSettings, oData) {
              localStorage.setItem('offersDataTables', JSON.stringify(oData));
          },
          "fnStateLoad": function (oSettings) {
              return JSON.parse(localStorage.getItem('offersDataTables'));
          },
          "autoWidth": false,
          "dom": '<"top"flp<"clear">>rt<"bottom"ip<"clear">>',
          "pageLength": 10,
          "columnDefs": [
          //   { "targets": 0,"width": "10px","orderable": false,"sortable": false},
            { "targets": 0,"width": "72px" },//title
            { "targets": 1,"width": "51px" },//company
            { "targets": 2,"width": "270px" },//descr
            { "targets": 3,"width": "96px" },//categ
            { "targets": 4,"width": "31px" },//tags
            { "targets": 5,"sortable": false,"width": "85px" } //action
          //   // { "targets": 7,"width": "24px" },
          //   // { "targets": 8,"width": "10px" },//favorite
          ],
          responsive: true,
          // "order": [[ 2, "desc" ]],
          "processing": true,
          "initComplete": function(settings, json) {
              $('.loading').hide();
          }
      });
    }
    else{

      var myTable = $('#example').DataTable({
          // "bStateSave": true,
          "fnStateSave": function (oSettings, oData) {
              localStorage.setItem('offersDataTables', JSON.stringify(oData));
          },
          "fnStateLoad": function (oSettings) {
              return JSON.parse(localStorage.getItem('offersDataTables'));
          },
          "autoWidth": false,
          "dom": '<"top"flp<"clear">>rt<"bottom"ip<"clear">>',
          "pageLength": 10,
          "columnDefs": [
          //   { "targets": 0,"width": "10px","orderable": false,"sortable": false},
            { "targets": 1,"width": "73px" },//company
            { "targets": 2,"width": "400px" },//descr
            { "targets": 3,"width": "300px" },//category
          //   { "targets": 4,"width": "24px" },//score
            { "targets": 5,"sortable": false,"width": "35px" } //Action
          //   // { "targets": 7,"width": "24px" },
          //   // { "targets": 8,"width": "10px" },//favorite
          ],
          responsive: true,
          // "order": [[ 2, "desc" ]],
          "processing": true,
          "initComplete": function(settings, json) {
              $('.loading').hide();
          }
      });
    }
    $('#filteredEntries').html(' = '+myTable.page.info().recordsTotal+ ' results');
    // yadcf.init(myTable, [
    // {
    //     column_number : 3,
    //     filter_type: "multi_select",
    //     select_type: 'select2'
    // },
    // {
    //     column_number: 5,
    //     select_type: 'select2',
    //     select_type_options: {
    //         width: '150px',
    //         placeholder: 'Select tag',
    //         allowClear: true  // show 'x' (remove) next to selection inside the select itself
    //     },
    //     column_data_type: "html",
    //     html_data_type: "text",
    //     filter_reset_button_text: false // hide yadcf reset button
    // }
    // ]);
    $(document).on("click", ".openurl", function() {
        $url = $(this).closest('tr').data('url');
        window.open($url);
        return false;
    });
    // $(document).on("click", ".edit", function() {
    //     $id = $(this).closest('tr').data('id');
    //     $('#hidden').val($id);
    //     var tags = $(this).closest('tr').find(".hiddentags").val().split(',');
    //     $("#select2").val(tags).trigger("change");
    // });
    $("#viewcategory").on('shown.bs.modal', function(e){

        var id = $(e.relatedTarget).parents('tr').data('id');
        $('#categoryhidden').val(id);

    });
    $("#viewdescription").on('shown.bs.modal', function(e){

        var id = $(e.relatedTarget).parents('tr').data('id');
        var descr = $(e.relatedTarget).html();
        $('#modaldescription').val(descr);
        $('#descriptionhidden').val(id);

    });
    $("#tagsEdit").on('shown.bs.modal', function(){
        var id = $("#hidden").val();
        var tag_display= [];
        $.ajax({
            'url':'tags.php',
            'type':'POST',
            'dataType': 'json',
            'data':{id: id,type:'fetch'},
            'success':function(response){
              $('#select2').empty().trigger("change").append(
                  $.map(response.result, function(v, i){
                    return $('<option>', { val: v.name, text: v.name });
                  })
                );
              if(response.selected != ''){
                $("#select2").val(response.selected.split(',')).trigger("change");
              }
            }
        });
    });

    // $(document).on('click','[class^="star-"]',function(){
    //     var $this = $(this);
    //     var id = $this.closest('tr').data('id');
    //     $.ajax({
    //         'url':'tags.php',
    //         'type':'POST',
    //         'dataType': 'json',
    //         'data':{id: id,type:'favorite'},
    //         'success':function(response){
    //             if(response.status == true){
    //               $this.toggleClass("star-on star-off");
    //             }
    //         }
    //     });
    // });

    $(document).on('click','.savecategory',function(){
        var category = $("#category_filter").val();
        var id = $("#categoryhidden").val();
        $.ajax({
            'url':'tags.php',
            'type':'POST',
            'dataType': 'json',
            'data':{id: id,category:category,type:'categoryupdate'},
            'success':function(response){
              console.log(response);
                if(response.status == true){
                  $('tr[data-id="'+id+'"]').find(".categoryname").html(response.category);
                }
            }
        });
    });
    $(document).on('click','.savedescription',function(){
        var descr = $("#modaldescription").val();
        var id = $("#descriptionhidden").val();
        // console.log(descr);
        $.ajax({
            'url':'tags.php',
            'type':'POST',
            'dataType': 'json',
            'data':{id: id,descr:descr,type:'descrupdate'},
            'success':function(response){
              console.log(response);
                if(response.status == true){
                  $('tr[data-id="'+id+'"]').find(".descriptionname").html(response.descr);
                }
                else{
                  alert(response.error);
                }
            }
        });
    });

    $(document).on('click','.savetags',function(){
        var id = $("#hidden").val();
        var tags = $("#select2").val();
        $.ajax({
            'url':'tags.php',
            'type':'POST',
            'dataType': 'json',
            'data':{id: id,tags:tags,type:'update'},
            'success':function(response){
                if(response.status == true){
                  $('[data-id="'+id+'"]').find(".tags").html(response.html);
                  $('[data-id="'+id+'"]').find(".hiddentags").val(tags.join());
                  // myTable.draw();
                }
            }
        });
    });
    // function delete_all(){
    //     var allVals = [];
    //     $(".s_check:checked").each(function() {
    //         allVals.push($(this).closest('tr').data('id'));
    //     });
    //     if(allVals.length <=0)
    //         alert("Please select row.");
    //     else
    //     {
    //         WRN_PROFILE_DELETE = "Are you sure you want to delete "+allVals.length+" row/s?";
    //         var check = confirm(WRN_PROFILE_DELETE);
    //         if(check == true)
    //         {
    //             $.ajax({
    //                 'url':'delete.php',
    //                 'type':'POST',
    //                 'data':{id: allVals,type:'mass'},
    //                 'success':function(response){
    //                     $.each(allVals,function(index,val) {
    //                         $('[data-id="'+val+'"]').remove();
    //                     });
    //                 $("#check_all").prop('checked',false);

    //                     // if(response == 'success')
    //                     // $this.closest('tr').hide();
    //                 }
    //             });
    //         }
    //     }
    // }
    // $(document).on('click','.delete_all',delete_all);
    // $(document).on('click','#check_all',function(){
    //     if($(this).is(':checked',true))
    //         $(".s_check").prop('checked', true);
    //     else
    //         $(".s_check").prop('checked',false);
    // });
    $(document).on('click','#downloadcsv',function(){

        WRN_DOWNLOAD = "Downlaod github ready CSV ?";
        var check = confirm(WRN_DOWNLOAD);
        if(check == true)
        {
          $.ajax({
              'url':'db.php',
              'type':'POST',
              'dataType': 'json',
              'data':{type: 'downloadcsv'},
              'success':function(response){
                console.log(response);
                if(response.status == true){
                  alert(response.name);
                }
                else{
                  alert(response.error);
                }
              }
          });
        }

    });


    $(document).on('click','#db_backup',function(){

        WRN_PROFILE_DELETE = "Are you sure you want to backup ext-table ?";
        var check = confirm(WRN_PROFILE_DELETE);
        if(check == true)
        {
          $.ajax({
              'url':'db.php',
              'type':'POST',
              'dataType': 'json',
              'data':{type: 'db_backup'},
              'success':function(response){
                if(response.status == true){
                  alert('success');
                }
                else{
                  alert(response.error);
                }
                  // if(response == 'success')
                  //     $this.closest('tr').hide();
                  //   else
                  //     alert(response);
              }
          });
        }

    });

    $(document).on('click','.delete',function(){
        $this = $(this);
        console.log($this.prop('class'));
        $id = $this.closest('tr').data('id');

        WRN_PROFILE_DELETE = "Are you sure you want to delete id #"+$id+" ?";
        var check = confirm(WRN_PROFILE_DELETE);
        if(check == true)
        {
          alert('check done');
          // $.ajax({
          //     'url':'delete.php',
          //     'type':'POST',
          //     'data':{id: $id},
          //     'success':function(response){
          //         if(response == 'success')
          //             $this.closest('tr').hide();
          //           else
          //             alert(response);
          //     }
          // });
        }

    });
});
</script>
</body>
</html>