<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "magehub";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}

$cat = [
	"translations" => "Translations & Localization",
	"mobile" => "Mobile",
	"personalization" => "Personalization & Experience Management",
	"productcontent" => "Product Content",
	"richmedia" => "Rich Media",
	"sitesearch" => "Site Search & Navigation",
	"blog" => "Blog",
	"social" => "Social",
	"marketplaceaddon" => "Marketplace Add-Ons",
	"marketplacesolutions" => "Marketplace Solutions",
	"addressverification" => "Address Verification",
	"crossborderfulfil" => "Cross Border Fulfillment",
	"ordermgmt" => "Order Management (OMS)",
	"warehousemgmt" => "Warehouse Management System (WMS)",
	"shippingcustom" => "Shipping Customizations",
	"helpdesk" => "Helpdesk",
	"livechat" => "Livechat",
	"erp" => "ERP & Accounting",
	"taxes" => "Taxes",
	"checkout" => "Checkout Enhancements",
	"fraud" => "Fraud Prevention",
	"payment" => "Payment Integration",
	"testing" => "Testing & Segmentation",
	"hosting" => "Hosting",
	"sitemonitoring" => "Site Monitoring",
	"performance" => "Performance",
	"sitemap" => "Sitemap",
	"reporting" => "Reporting & Analytics",
	"admintools" => "Admin Tools",
	"emailmarketing" => "Email Marketing",
	"crm" => "CRM",
	"seo" => "SEO/SEM",
	"marketingautomation" => "Marketing Automation",
	"advertising" => "Advertising",
	"comarisonshoppingengines" => "Comparison Shopping Engines",
	"gifts" => "Gifts",
	"marketplacefeeds" => "Marketplace Feeds",
	"pos" => "Point of Service (POS)",
	"pricingpromotions" => "Pricing & Promotions",
	"loyaltyrewards" => "Rewards & Loyalty"];

$filename = '/var/www/html/MageHub/LPT/csv/freecsv/marketplace_magento_all_856.csv';

// ALTER TABLE ext MODIFY COLUMN company VARCHAR(255)  
//     CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL;
// $filename = '/var/www/html/MageHub/LPT/csv/freecsv/marketplace_err.csv';
$final = [];
$i = 0;
$errors = array();
if (($h = fopen("{$filename}", "r")) !== false)
{
    while (($data = fgetcsv($h, 2000, ",")) !== false)
    {
		// print_r($data);
        if ($i != 0 && $i > 298)
        // if ($i != 0)
        {
            $title = $data[2];
            $description = $data[9];
            $description = str_replace("'", "\'", $description);
            $price = 0;
            // print_r($price);die;
            $url = $data[1];
            $avg_review = $data[3];
            $image = $data[6];
            $company = str_replace("'", "\'", iconv("ISO-8859-1", "UTF-8", trim($data[7]))); //'Sparsh';
            $categories = explode(',', $data[13]);
            if (isset($categories[1]))
            {
                $key = array_search(trim($categories[1]) , $cat);
                if ($key == false)
                {
                    if (isset($categories[2]))
                    {
                        $key = array_search(trim($categories[2]) , $cat);

                        if ($key == false)
                        {
                            if (isset($categories[3]))
                            {
                                $key = array_search(trim($categories[3]) , $cat);
                            }

                            else
                            {
                                $key = $categories[1];
                                // echo $data[13]; echo "no3<br>";
                                
                            }
                        }
                        // else{
                        // 	//echo $key; echo "<br>";
                        // }
                        
                    }

                    else
                    {
                        $key = $categories[1];

                        // echo $data[13]; echo "no2<br>";
                        
                    }
                }
                // else{
                // 	//echo $key; echo "<br>";
                // }
                
            }
            else
            {
                // echo $data[13]; echo "no1<br>";
                $key = $categories[0];

            }

            // print_r($data[13]);echo " : ";print_r($key); echo "<br>";
            $tags = str_replace(array(
                'Extensions, '
            ) , '', $data[13]);
            $category = $key; //$data[5];
            $github_link = ''; // $data[8];
            $reviewcount = str_replace(array(
                '(',
                ')'
            ) , '', $data[4]);
            $current_version = $data[10];
            $updated = $data[11];
            $thirdparty = (strpos($data[5], 'Integration') !== false) ? 1 : 0;
            $require_license = 0; //$data[0];
            $pwa_ready = 0;
            $final = array_unique(array_merge($final, $categories));

            // echo "<pre>";
            // echo $i;
            // echo $url;
            // echo $i == 295 ? $url : $i;
            // echo $i == 165 ? $url : '';
            // echo '<br>';

			// print_r($data);
			// echo '<br>';
            $sql = "INSERT INTO ext(title,description,price,url,avg_review,image,company,tags,category,github_link,reviewcount,current_version,updated,thirdparty,require_license,pwa_ready) VALUES ('$title','$description','$price','$url','$avg_review','$image','$company','$tags','$category','$github_link','$reviewcount','$current_version','$updated','$thirdparty','$require_license','$pwa_ready')";
            print_r($sql);
            die;
			// echo '<br>';
            // if (!mysqli_query($conn, $sql))
            // {
            //     print_r($data);
            //     echo '<br>';
            //     // print_r($title);
            //     // echo '<br>';
            //     // print_r($description);
            //     // echo '<br>';
            //     // print_r($price);
            //     // echo '<br>';
            //     print_r($company);
            //     echo '<br>';
            //     print_r($sql);
            //     // $errors[] = mysqli_error($conn);
            //     echo json_encode(array(
            //         'status' => false,
            //         'error' => mysqli_error($conn)
            //     ));
            //     die;
            // }
        }
        $i++;
    }

    fclose($h);
}
print_r($final);
$trimmed_array = array_filter(array_map('trim', $final));
print_r($trimmed_array);

foreach ($trimmed_array as $ccc)
{
    $key = array_search($ccc, $cat);
    echo $key;
    echo '<br>';
}
echo "endsuccess";