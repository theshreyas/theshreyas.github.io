<?php

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "magehub";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


$filename = 'csv/magecomp.csv';
$i=0;
$errors = array();
if (($h = fopen("{$filename}", "r")) !== FALSE) 
{
	while (($data = fgetcsv($h, 1000, ",")) !== FALSE) 
	{
		if($i != 0){
			// print_r($data);
			$title = $data[7];
			$price = $data[2];
			$price = str_replace(array('$',','), '', $price);
			// if(strpos($price, 'Regular Price') !== false){
			// 	$prices = explode('Regular Price', $price);
			// 	$price = explode('Special Price', $prices[0]);
			// 	$price = $price[1];
			// }
			// echo $price;
			// echo "<br>";
			$avg_review = $data[3];
			$description = $data[8];
			// print_r($price);die;
			$url = $data[6];
			$image = $data[4];
			$company = 'Magecomp';
			$tags = '';//$data[0];
			$category = '';//$data[5];
			$github_link = '';//$data[0];
			$require_license = 0;//$data[0];

			$sql = "INSERT INTO ext(title,description,price,url,avg_review,image,company,tags,category,github_link,require_license) VALUES ('$title','$description','$price','$url','$avg_review','$image','$company','$tags','$category','$github_link','$require_license')";
			// echo $sql;die;
			if(!mysqli_query($conn, $sql)){
				$errors[] = mysqli_error($conn);
				// echo json_encode(array('status'=>false,'error'=>mysqli_error($conn)));
			}
		}
		$i++;
	}

	fclose($h);
}