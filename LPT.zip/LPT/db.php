<?php
$servername = "localhost";
$username   = "root";
$password   = "root";
$dbname     = "magehub";
$conn       = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_POST['type'] && $_POST['type'] == 'db_backup') {

    $tablename = 'ext_' . date("dMhi");
    $sql       = "CREATE TABLE $tablename LIKE ext;";
    if (mysqli_query($conn, $sql)) {
        $sql = "INSERT INTO $tablename SELECT * FROM ext;";
        if (mysqli_query($conn, $sql)) {
            echo json_encode(array('status' => true));
        } else {
            echo json_encode(array('status' => false, 'error' => mysqli_error($conn)));
        }
    } else {
        echo json_encode(array('status' => false, 'error' => mysqli_error($conn)));
    }
}
if ($_POST['type'] && $_POST['type'] == 'downloadcsv') {

    $result = mysqli_query($conn, "SELECT * FROM ext where price = 0;");
    if ($result) {

        $filename = "ext_" . rand() . ".csv";
        $f        = fopen($filename, 'w');
        $std_num  = 0;
        while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            fputcsv($f, $row, ",");
        }
        fseek($f, 0);
        fpassthru($f);
        fclose($f);
        echo json_encode(array('status' => true, 'name' => dirname(__FILE__) . '/' . $filename));
    } else {
        echo json_encode(array('status' => false, 'error' => mysqli_error($conn)));
    }
}
