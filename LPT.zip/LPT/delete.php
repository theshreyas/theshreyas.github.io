<?php
$id = $_POST['id'];
// echo $ids;
// $id_string = "'".implode("','",$ids)."'"; //implode(",",$ids);
// echo $id_string;die;
$servername = "localhost";
$username   = "root";
$password   = "root";
$dbname     = "magehub";
// try{
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// $sql = "UPDATE ext SET deleted = 1 WHERE lpt_id IN ($id_string)";
$sql = "INSERT INTO deleted SELECT e.* FROM ext e WHERE id = " . $id . ";";
$conn->query($sql);

$sql = "DELETE FROM ext WHERE id = " . $id;
if (mysqli_query($conn, $sql)) {
    echo "success";
} else {
    echo $id . mysqli_error($conn);
}
mysqli_close($conn);
// }
// catch(Throwable $e) {
//     echo 'Message: ' .$e->getMessage();
//     file_put_contents('log/deletelog_'.date("j.n.Y").'.txt', 'Message: ' .$e->getMessage().PHP_EOL, FILE_APPEND);

// }
// delete duplicate entries
// DELETE n1 FROM ext n1, ext n2 WHERE n1.id > n2.id AND n1.lpt_id = n2.lpt_id
// select distinct values against count
// SELECT `lpt_id`, COUNT(*) FROM ext GROUP BY `lpt_id` having count(*) > 1
