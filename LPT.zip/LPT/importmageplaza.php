<?php

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "magehub";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


$filename = '/home/hp/Downloads/mageplazadescr.csv';

$i=0;
$errors = array();
if (($h = fopen("{$filename}", "r")) !== FALSE) 
{
	while (($data = fgetcsv($h, 1000, ",")) !== FALSE) 
	{
		if($i != 0 ){
			// $title = $data[3];
			$url = $data[1];
			$description = $data[2];
			// $price = $data[4];
			// if(strtolower($price) == 'free'){
			// 	$price = 0;	
			// }
			// $price = str_replace(array('$',','), '', $price);
			// $url = $data[8];
			// $avg_review = $data[5];
			// $image = $data[6];
			// $company = 'Mageplaza';
			// $tags = '';//$data[0];
			// $category = $data[2];
			// $category = str_replace('Magento 2 ', '', $category);
			// $github_link = '';//$data[0];
			// $require_license = 0;//$data[0];
			$description =  addcslashes($description, "'");

			$sql = "update ext set description = '$description' where url = '$url'";
			// echo $sql;die;
			// $sql = "INSERT INTO ext(title,description,price,url,avg_review,image,company,tags,category,github_link,require_license) VALUES ('$title','$description','$price','$url','$avg_review','$image','$company','$tags','$category','$github_link','$require_license')";

			if(!mysqli_query($conn, $sql)){
				$errors[] = mysqli_error($conn);
				echo $sql;	
			// 	// echo json_encode(array('status'=>false,'error'=>mysqli_error($conn)));
			}
		}
		$i++;
	}

	fclose($h);
}
print_r($errors);